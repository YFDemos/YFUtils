//
//  YFDatePickerView.h
//  YFUtils
//
//  Created by WangYunFei on 16/12/22.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, YFDatePickerViewType){
    YFDatePickerViewType_time = UIDatePickerModeTime,
    YFDatePickerViewType_dateAndTime = UIDatePickerModeDateAndTime,
    YFDatePickerViewType_date = UIDatePickerModeDate,
    YFDatePickerViewType_yearAndMonth = 99
};

typedef void(^YFDatePickerView_finishHandleBlock)(id obj, UIButton *sender, id userInfo, BOOL *canDisappear);
typedef void(^YFDatePickerView_dateChangeHandleBlock)(id sender, id userInfo, UILabel *timeLabel);
typedef void(^YFDatePickerView_dateDisappearHandleBlock)();

@interface YFDatePickerView : UIControl

// 时间
@property (nonatomic, strong) NSDate *date;
// 开始时间
@property (nonatomic, strong) NSDate *startDate;
// 结束时间
@property (nonatomic, strong) NSDate *endDate;
// 选择器类型，默认为dateAndTime
@property (nonatomic, assign) YFDatePickerViewType selectType;
// 完成按钮
@property (nonatomic, strong, readonly) UIButton *finishBtn;
// 时间Label
@property (nonatomic, strong) UILabel *timeLabel;

/*
 *  完成按钮回调块
 */
@property (nonatomic, copy) YFDatePickerView_finishHandleBlock finishHandleBlock;

/*
 *  日期改变回调块
 */
@property (nonatomic, copy) YFDatePickerView_dateChangeHandleBlock dateChangeHandleBlock;

/*
 *  选择器消失回调块
 */
@property (nonatomic, copy) YFDatePickerView_dateDisappearHandleBlock disappearHandleBlock;

- (void)setFinishHandleBlock:(YFDatePickerView_finishHandleBlock)finishHandleBlock;

- (void)setDateChangeHandleBlock:(YFDatePickerView_dateChangeHandleBlock)dateChangeHandleBlock;

- (void)setDisappearHandleBlock:(YFDatePickerView_dateDisappearHandleBlock)disappearHandleBlock;

- (void)setDatePickerMaxDate:(NSDate *)maxDate minDate:(NSDate *)minDate;

// 显示选择器
- (void)show;
// 去掉选择器
- (void)dismiss;

@end
