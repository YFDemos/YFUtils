//
//  YFHintViewUtils.m
//  YFUtils
//
//  Created by WangYunFei on 16/11/14.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "YFHintViewUtils.h"

@implementation YFHintViewUtils

// 添加全屏的等待动画
+ (UIView *)fullWaitingViewWith:(CGRect)waitingViewRect text:(NSString *)waitingText{

    CGSize waitingTextSize = [waitingText boundingRectWithSize:CGSizeMake(waitingViewRect.size.width, 22) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:18]} context:nil].size;
    
    CGRect activityRect;
    activityRect.size = CGSizeMake(40, 40);
    CGFloat waitingHeight = waitingTextSize.height + 40 + 10;
    activityRect.origin.x = (waitingViewRect.size.width - 40)/2;
    activityRect.origin.y = (waitingViewRect.size.height - waitingHeight)/2;
    
    UIActivityIndicatorView *waitingAnimatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    waitingAnimatorView.frame = activityRect;
    [waitingAnimatorView startAnimating];
    
    UIView *waitingView = [[UIView alloc] initWithFrame:waitingViewRect];
    waitingView.backgroundColor = [UIColor  colorWithWhite:0.711 alpha:0.325];
    [waitingView addSubview:waitingAnimatorView];
    
    UILabel *waitingTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, activityRect.origin.y + 40 + 10, waitingViewRect.size.width, waitingTextSize.height)];
    waitingTextLabel.text = waitingText;
    waitingTextLabel.font = [UIFont systemFontOfSize:16];
    waitingTextLabel.backgroundColor = [UIColor clearColor];
    waitingTextLabel.textAlignment = NSTextAlignmentCenter;
    waitingTextLabel.textColor = [UIColor whiteColor];
    [waitingView addSubview:waitingTextLabel];
    
    return waitingView;
}

// 带图片和文本的提示视图
+ (UIView *)hintViewWithImageAndText:(CGRect)hintViewRect hintImage:(UIImage *)hintImage text:(NSString *)hintText{

    UIView *hintView = [[UIView alloc] initWithFrame:hintViewRect];
    hintView.backgroundColor = [UIColor clearColor];
    
    CGFloat navBarHeight = 64.f;
    CGFloat textHeight = 40.f;
    CGFloat imageWidth = 80.f;
    CGFloat imageHeight = hintImage.size.height/hintImage.size.width * imageWidth;
    CGRect imageRect = CGRectMake((hintViewRect.size.width - imageWidth)/2, (hintViewRect.size.height - imageHeight - textHeight - navBarHeight)/2, imageWidth, imageHeight);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:imageRect];
    imageView.image = hintImage;
    
    
    CGRect textRect = CGRectMake(0, imageRect.origin.y + imageRect.size.height, hintViewRect.size.width, textHeight);
    
    UILabel *textLabel = [[UILabel alloc] initWithFrame:textRect];
    textLabel.text = hintText;
    textLabel.font = [UIFont systemFontOfSize:16];
    textLabel.textColor = [UIColor lightGrayColor];
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.backgroundColor = [UIColor clearColor];
    
    [hintView addSubview:imageView];
    [hintView addSubview:textLabel];
    
    return hintView;
}

// 带文本的提示视图
+ (UIView *)hintViewWithText:(CGRect)hintViewRect hintText:(NSString *)hintText{

    UIView *hintView = [[UIView alloc] initWithFrame:hintViewRect];
    hintView.backgroundColor = [UIColor clearColor];
    
    CGRect textRect = CGRectMake(0, hintViewRect.size.height/2 - 10, hintViewRect.size.width, 70);
    UILabel *textLabel = [[UILabel alloc] initWithFrame:textRect];
    textLabel.text = hintText;
    textLabel.font = [UIFont systemFontOfSize:16];
    textLabel.textColor = [UIColor lightGrayColor];
    textLabel.textAlignment = NSTextAlignmentCenter;
    [hintView addSubview:textLabel];
    
    return hintView;
}

// 带图片的提示视图
+ (UIView *)hintViewWithImage:(CGRect)hintViewRect hintImage:(UIImage *)hintImage{

    UIView *hintView = [[UIView alloc] initWithFrame:hintViewRect];
    hintView.backgroundColor = [UIColor whiteColor];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:hintViewRect];
    imageView.image = hintImage;
    [hintView addSubview:imageView];
    
    return hintView;
}

@end
