//
//  YFDatePickerView.m
//  YFUtils
//
//  Created by WangYunFei on 16/12/22.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "YFDatePickerView.h"

@interface YFDatePickerView ()

@property (nonatomic, strong) UIDatePicker *datePickerView;

@property (nonatomic, strong) UIView *toolView;

@property (nonatomic, strong) UIView *containView;

@property (nonatomic, strong) UIView *dayCoverViewL;

@property (nonatomic, strong) UIView *dayCoverViewR;

@property (nonatomic, assign) BOOL isPickDateViewShow;

@end

static const CGFloat kToolViewHeight = 40.f;
static const CGFloat kFinishBtnWidth = 80.f;
static const CGFloat kTop = 10.f;
static const NSInteger kPickDateViewHeight = 256;

@implementation YFDatePickerView

- (id)init{

    self = [super init];
    if (self) {
        [self setUpView];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        [self setUpView];
    }
    return self;
}

- (void)setUpView{

    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    
    self.frame = CGRectMake(0, 0, screenSize.width, screenSize.height);
    self.backgroundColor = [UIColor colorWithWhite:0.727 alpha:0.33];
    [self addTarget:self action:@selector(cancelPickDateView) forControlEvents:UIControlEventTouchDown];
    
    
    _containView = [[UIControl alloc] initWithFrame:CGRectMake(0, screenSize.height, screenSize.width, kPickDateViewHeight)];
    _containView.backgroundColor = [UIColor whiteColor];
    
    
    CGFloat fixedX = 6.f;
    _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(kTop + fixedX, kTop/2, screenSize.width - kTop * 2 - kFinishBtnWidth, kToolViewHeight - kTop)];
    _timeLabel.backgroundColor = [UIColor clearColor];
    _timeLabel.text = [self getDateTime:[[NSDate date] timeIntervalSince1970]];
    _timeLabel.textColor = [UIColor colorWithRed:153.0/255.0 green:153.0/255.0 blue:153.0/255.0 alpha:1.0];
    
    
    _finishBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _finishBtn.frame = CGRectMake(screenSize.width - kTop - kFinishBtnWidth + fixedX * 2, kTop/2, kFinishBtnWidth, kToolViewHeight - kTop);
    _finishBtn.backgroundColor = [UIColor clearColor];
    [_finishBtn setTitle:@"完成" forState:UIControlStateNormal];
    [_finishBtn setTitleColor:[UIColor colorWithRed:71.0/255.0 green:155.0/255.0 blue:255.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_finishBtn addTarget:self action:@selector(onFinishBtnPressed:) forControlEvents:UIControlEventTouchUpInside];

    
    _toolView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenSize.width, kToolViewHeight)];
    _toolView.backgroundColor = [UIColor colorWithRed:244.0/255.0 green:244.0/255.0 blue:244.0/255.0 alpha:1.0];
    [_toolView addSubview:_timeLabel];
    [_toolView addSubview:_finishBtn];
    [_containView addSubview:_toolView];

    
    _datePickerView = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, kToolViewHeight, screenSize.width, kPickDateViewHeight - kToolViewHeight)];
    _datePickerView.backgroundColor = [UIColor whiteColor];
    _datePickerView.datePickerMode = YFDatePickerViewType_dateAndTime;
    _datePickerView.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    // 选项滑动时变化 UIControlEventValueChanged
    [_datePickerView addTarget:self action:@selector(timeChange) forControlEvents:UIControlEventValueChanged];
    
    [_containView addSubview:_datePickerView];
    [_containView addSubview:self.dayCoverViewL];
    [_containView addSubview:self.dayCoverViewR];
    
    [self addSubview:_containView];
}

- (void)onFinishBtnPressed:(UIButton *)button{

    BOOL canDisappear = YES;
    if (_finishHandleBlock){
        _finishHandleBlock(self, button, _datePickerView.date, &canDisappear);
    }else{
    }
    
    if (canDisappear){
        [self dismiss];
    }
}

- (void)setSelectType:(YFDatePickerViewType)selectType{

    if (_datePickerView.datePickerMode == (UIDatePickerMode)selectType){
        return;
    }
    _selectType = selectType;
    
    if (_selectType == YFDatePickerViewType_yearAndMonth){
        self.dayCoverViewL.hidden = NO;
        self.dayCoverViewR.hidden = NO;
        _datePickerView.datePickerMode = UIDatePickerModeDate;
        
        // 选择年月时，把时间调整到每个月的第一天
        NSDate *date = self.date ? self.date : [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyyM"];
        NSString *dateStr = [dateFormatter stringFromDate:date];
        NSString *year = [dateStr substringWithRange:NSMakeRange(0, 4)];
        NSString *month = [dateStr substringFromIndex:4];
        NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
        NSDateComponents *comps = [[NSDateComponents alloc] init];
        comps.year = [year integerValue];
        comps.month = [month integerValue];
        self.date = [calendar dateFromComponents:comps];
        
        _datePickerView.frame = ({
            CGRect frame = _datePickerView.frame;
            frame.origin = CGPointMake(40, kToolViewHeight);
            frame;
        });
        _timeLabel.text = [self getDateMonthFrom:[self.date timeIntervalSince1970]];
    }else{
        self.dayCoverViewL.hidden = YES;
        self.dayCoverViewR.hidden = YES;
        _datePickerView.datePickerMode = (UIDatePickerMode)selectType;
        _datePickerView.frame = ({
            CGRect frame = _datePickerView.frame;
            frame.origin = CGPointMake(0, kToolViewHeight);
            frame;
        });
        
        if (_datePickerView.datePickerMode == UIDatePickerModeDate){
            if (self.date){
                _timeLabel.text = [self getDate:[self.date timeIntervalSince1970]];
            }else{
                _timeLabel.text = [self getDate:[[NSDate date] timeIntervalSince1970]];
            }
        }else if (_datePickerView.datePickerMode == UIDatePickerModeTime){
            _timeLabel.text = [self getFullTime:[self.date timeIntervalSince1970]];
        }
    }
}

- (void)setDatePickerMaxDate:(NSDate *)maxDate minDate:(NSDate *)minDate{

    _datePickerView.maximumDate = maxDate;
    _datePickerView.minimumDate = minDate;
}

- (void)timeChange{
    NSDate *selectDate = self.datePickerView.date;
    if (_selectType == YFDatePickerViewType_yearAndMonth) {
        self.timeLabel.text = [self getDateMonthFrom:[self.date timeIntervalSince1970]];
    }
    else {
        if (_datePickerView.datePickerMode == UIDatePickerModeDate) {
            self.timeLabel.text = [self getDate:[selectDate timeIntervalSince1970]];
        }
        else if (_datePickerView.datePickerMode == UIDatePickerModeTime){
            _timeLabel.text = [self getFullTime:[self.date timeIntervalSince1970]];
        }else{
            self.timeLabel.text = [self getDateTime:[selectDate timeIntervalSince1970]];
        }
    }
    
    if (_dateChangeHandleBlock) {
        _dateChangeHandleBlock(_datePickerView, _datePickerView.date, _timeLabel);
    }
}

- (void)setDate:(NSDate *)date{
    
    [self.datePickerView setDate:date];
    
    if (_selectType == YFDatePickerViewType_yearAndMonth){
        self.timeLabel.text = [self getDateMonthFrom:[self.date timeIntervalSince1970]];
    }
    else {
        if (_datePickerView.datePickerMode == UIDatePickerModeDate){
            self.timeLabel.text = [self getDate:[date timeIntervalSince1970]];
        }
        else if (_datePickerView.datePickerMode == UIDatePickerModeTime){
            self.timeLabel.text = [self getFullTime:[date timeIntervalSince1970]];
        }else{
            self.timeLabel.text = [self getDateTime:[date timeIntervalSince1970]];
        }
    }
}

- (NSDate *)date{

    return self.datePickerView.date;
}

- (void)drawRect:(CGRect)rect{

    [super drawRect:rect];
    
    if (self.startDate != nil){
        self.datePickerView.minimumDate = self.startDate;
    }
    
    if (self.endDate != nil){
        self.datePickerView.maximumDate = self.endDate;
    }
}

- (void)show{

    [[UIApplication sharedApplication].keyWindow addSubview:self];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self datePickerView:YES];
    });
}

- (void)dismiss{

    [self datePickerView:NO];
    
    if (_disappearHandleBlock){
        _disappearHandleBlock();
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self removeFromSuperview];
    });
}

- (void)datePickerView:(BOOL)isShow{
    
    CGSize deviceSize = [UIScreen mainScreen].bounds.size;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    
    if (isShow){
        self.isPickDateViewShow = YES;
        _containView.frame = CGRectMake(0, deviceSize.height - kPickDateViewHeight, deviceSize.width, kPickDateViewHeight);
    }else{
        self.isPickDateViewShow = NO;
        _containView.frame = CGRectMake(0, deviceSize.height, deviceSize.width, kPickDateViewHeight);
    }
    
    [UIView commitAnimations];
}

- (void)cancelPickDateView{
    
    [self dismiss];
}

- (UIView *)dayCoverViewL{

    if (!_dayCoverViewL){
        _dayCoverViewL = [[UIView alloc] initWithFrame:CGRectMake(0, 40, 70, kPickDateViewHeight - 40)];
        _dayCoverViewL.backgroundColor = [UIColor whiteColor];
        _dayCoverViewL.hidden = YES;
    }
    
    return _dayCoverViewL;
}

- (UIView *)dayCoverViewR{

    if (!_dayCoverViewR){
        _dayCoverViewR = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.bounds) - 80, 40, 80, kPickDateViewHeight - 40)];
        _dayCoverViewR.backgroundColor = [UIColor whiteColor];
        _dayCoverViewR.hidden = YES;
    }
    
    return _dayCoverViewR;
}

// 传入秒数，返回年月日时分
- (NSString *)getDateTime:(long long)seconds{

    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:seconds];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyy-MM-dd HH:mm"];
    NSString *timeStr = [dateFormatter stringFromDate:date];
    
    return timeStr;
}

// 传入秒数，返回年月日
- (NSString *)getDate:(long long)seconds{
    
    NSDate *date =[[NSDate alloc] initWithTimeIntervalSince1970:seconds];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *timeStr = [dateFormatter stringFromDate:date];
    
    return timeStr;
}

// 传入秒数，返回年月
- (NSString *)getDateMonthFrom:(long long)seconds{

    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:seconds];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy年M月"];
    NSString *timeStr = [dateFormatter stringFromDate:date];
    
    return timeStr;
}

// 传入秒数，返回时分
- (NSString *)getFullTime:(long long)seconds{

    NSDate *date =[[NSDate alloc] initWithTimeIntervalSince1970:seconds];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm"];
    NSString *timeStr = [dateFormatter stringFromDate:date];
    
    return timeStr;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
