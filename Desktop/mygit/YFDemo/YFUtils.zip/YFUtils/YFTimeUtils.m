//
//  YFTimeUtils.m
//  YFUtils
//
//  Created by WangYunFei on 16/11/10.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "YFTimeUtils.h"

@implementation YFTimeUtils

// 获取当前的年月日星期
+ (NSString *)currentTimeAndWeek{
    
    NSArray *weekArray = @[@"星期日", @"星期一", @"星期二", @"星期三", @"星期四", @"星期五", @"星期六"];
    
    NSDate *date = [NSDate date];
    // NSCalendarIdentifierChinese是中国农历
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *dateCopms = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    dateCopms = [calendar components:unitFlags fromDate:date];
    
    NSInteger day = [dateCopms day];
    NSInteger month = [dateCopms month];
    NSInteger year = [dateCopms year];
    NSInteger weekday = [dateCopms weekday];
    
    NSString *timeStr = [NSString stringWithFormat:@"%ld年%ld月%ld日，%@", year, month, day, weekArray[weekday - 1]];
    
    return timeStr;
}

// 传入date类型和相应格式，得到时间的字符串
+ (NSString *)yearAndMonthTime:(NSDate *)date format:(NSString *)format{

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    NSString *timeStr = [formatter stringFromDate:date];
    
    return timeStr;
}

#pragma mark - 传入date类型,得到年或月或日

// 传入date类型，得到天数
+ (NSInteger)dayOfDate:(NSDate *)date{

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *dateCopms = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    dateCopms = [calendar components:unitFlags fromDate:date];
    
    NSInteger day = [dateCopms day];
    
    return day;
}

// 传入date类型，得到月份
+ (NSInteger)monthOfDate:(NSDate *)date{
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *dateCopms = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    dateCopms = [calendar components:unitFlags fromDate:date];
    
    NSInteger month = [dateCopms month];
    
    return month;
}

// 传入date类型，得到年份
+ (NSInteger)yearOfDate:(NSDate *)date{
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *dateCopms = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    dateCopms = [calendar components:unitFlags fromDate:date];
    
    NSInteger year = [dateCopms year];
    
    return year;
}

// 传入date类型，得到星期几
+ (NSInteger)weekOfDate:(NSDate *)date{

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *dateCopms = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    dateCopms = [calendar components:unitFlags fromDate:date];
//  真机上需要设置区域，才能正确获取本地日期，中国:zh_CN
    calendar.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    NSInteger weekday = [dateCopms weekday];
    
    return weekday;
}

// 传入date类型,计算月份的天数
- (NSInteger)howManyDaysInThisDate:(NSDate *)date{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSRange range = [calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:date];
    NSInteger numberOfDaysInMonth = range.length;
    
    return numberOfDaysInMonth;
}

// 获得当前月的第几周
+ (NSInteger)weekOfMonth{
    
    NSDate *date = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar setFirstWeekday:1];
    NSDateComponents *comps;
    comps = [calendar components:NSCalendarUnitWeekOfMonth fromDate:date];
    NSInteger weekOfMonth = [comps weekOfMonth];
    
    return weekOfMonth;
}

#pragma mark - 传入秒数，输出完整时间
+ (NSString *)getChineseDetailDate:(long long)seconds{

    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:(seconds / 1000)];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy年MM月dd日HH:mm"];
    NSString *timeStr = [formatter stringFromDate:date];
    
    return timeStr;
}

+ (NSString *)getDateWithoutYear:(long long)seconds{

    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:(seconds / 1000)];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MM月dd日HH:mm"];
    NSString *timeStr = [formatter stringFromDate:date];
    
    return timeStr;
}

+ (NSString *)getDateWithoutHourAndMinute:(long long)seconds{

    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:(seconds / 1000)];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy年MM月dd日"];
    NSString *timeStr = [formatter stringFromDate:date];
    
    return timeStr;
}

// 得到现在时间的秒数
+ (long long)currentSeconds{

    NSDate *date = [NSDate date];
    return [date timeIntervalSince1970];
}

// long long to NSDate
+ (NSDate *)dateFromMillis:(long long)millis{

    return [NSDate dateWithTimeIntervalSince1970:(millis / 1000)];
}

#pragma mark - 判断

// 是否是同一天
+ (BOOL)isSameDay:(NSDate *)date anotherDate:(NSDate *)anotherDate{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    NSDateComponents *comp1 = [calendar components:unitFlags fromDate:date];
    NSDateComponents *comp2 = [calendar components:unitFlags fromDate:anotherDate];
    
    if ([comp1 day] == [comp2 day] &&
        [comp1 month] == [comp2 month] &&
        [comp1 year] == [comp2 year]){
        return YES;
    }else{
        return NO;
    }
}

// 是否是同一月
+ (BOOL)isSameMonth:(NSDate *)date anotherDate:(NSDate *)anotherDate{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    NSDateComponents *comp1 = [calendar components:unitFlags fromDate:date];
    NSDateComponents *comp2 = [calendar components:unitFlags fromDate:anotherDate];
    
    if ([comp1 month] == [comp2 month] &&
        [comp1 year] == [comp2 year]){
        return YES;
    }else{
        return NO;
    }
}

// 是否是同一年
+ (BOOL)isSameYear:(NSDate *)date anotherDate:(NSDate *)anotherDate{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSInteger unitFlags = NSCalendarUnitDay |
    NSCalendarUnitMonth |
    NSCalendarUnitYear |
    NSCalendarUnitWeekday |
    NSCalendarUnitSecond |
    NSCalendarUnitMinute |
    NSCalendarUnitHour;
    NSDateComponents *comp1 = [calendar components:unitFlags fromDate:date];
    NSDateComponents *comp2 = [calendar components:unitFlags fromDate:anotherDate];
    
    if ([comp1 year] == [comp2 year]){
        return YES;
    }else{
        return NO;
    }
}

@end
