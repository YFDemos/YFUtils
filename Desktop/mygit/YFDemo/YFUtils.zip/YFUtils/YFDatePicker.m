//
//  YFDatePicker.m
//  YFUtils
//
//  Created by WangYunFei on 16/12/12.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "YFDatePicker.h"
#import "ViewController.h"

#define kMainW [UIScreen mainScreen].bounds.size.width
#define kMainH [UIScreen mainScreen].bounds.size.height

@interface YFDatePicker ()

// 日期选择器
@property (nonatomic, strong) UIDatePicker *datePicker;
// 时间选择器
@property (nonatomic, strong) UIDatePicker *dayPicker;
@property (nonatomic, strong) UIButton *yearBtn;
@property (nonatomic, strong) UIButton *dayBtn;

- (void)datePickerHid:(BOOL)datePickerHid dayPickerHid:(BOOL)dayPickerHid dayBtnColor:(UIColor *)dayBtnColor yearBtnColor:(UIColor *)yearBtnColor;

@end

@implementation YFDatePicker

- (id)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        
        CGRect rect = self.frame;
        
        // 背景框
        UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, rect.size.width, rect.size.height)];
        bgView.backgroundColor = [UIColor colorWithWhite:0.961 alpha:1.0];
        [self addSubview:bgView];
        
        // 日期选择器
        _datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 95, rect.size.width, 150)];
        _datePicker.backgroundColor = [UIColor clearColor];
        [_datePicker setDatePickerMode:UIDatePickerModeDate];
        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
        _datePicker.locale = locale;
        NSDateFormatter *formatter_minDate = [[NSDateFormatter alloc] init];
        [formatter_minDate setDateFormat:@"yyyy年MM月dd日"];
        NSDate *minDate = [formatter_minDate dateFromString:@"1970-01-01"];
        formatter_minDate = nil;
        [_datePicker setMaximumDate:minDate];
        [self addSubview:_datePicker];
        
        // 时间选择器
        _dayPicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 95, rect.size.width, 150)];
        _dayPicker.backgroundColor = [UIColor clearColor];
        [_dayPicker setDatePickerMode:UIDatePickerModeTime];
        NSLocale *locale2 = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
        _dayPicker.locale = locale2;
        NSDateFormatter *formatter_minDate2 = [[NSDateFormatter alloc] init];
        [formatter_minDate setDateFormat:@"HH:mm"];
        NSDate *minDate2 = [formatter_minDate2 dateFromString:@"00:00"];
        formatter_minDate2 = nil;
        [_dayPicker setMaximumDate:minDate2];
        // 默认显示日期选择器，先隐藏时间选择器
        _dayPicker.hidden = YES;
        [self addSubview:_dayPicker];
        
        UILabel *upLineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 51, rect.size.width, 0.7)];
        upLineLabel.backgroundColor = [UIColor whiteColor];
        [self addSubview:upLineLabel];
        
        UILabel *downLineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 91, rect.size.width, 0.7)];
        downLineLabel.backgroundColor = [UIColor whiteColor];
        [self addSubview:downLineLabel];
        
        // 确定按钮
        UIButton *completeBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        completeBtn.frame = CGRectMake(rect.size.width - 65, 7, 65, 40);
        completeBtn.backgroundColor = [UIColor clearColor];
        [completeBtn setTitle:@"确定" forState:UIControlStateNormal];
        [completeBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        [completeBtn addTarget:self action:@selector(completeBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:completeBtn];
        
        // 取消按钮
        UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        cancelBtn.frame = CGRectMake(13, 7, 60, 40);
        cancelBtn.backgroundColor = [UIColor clearColor];
        [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        [cancelBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [cancelBtn addTarget:self action:@selector(cancelBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:cancelBtn];
        
        // 日期按钮
        _yearBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        _yearBtn.frame = CGRectMake((rect.size.width - kMainW * 0.36) * 0.35, 50, 60, 40);
        _yearBtn.backgroundColor = [UIColor clearColor];
        [_yearBtn setTitle:@"日期" forState:UIControlStateNormal];
        [_yearBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        _yearBtn.layer.cornerRadius = 5.0;
        [_yearBtn addTarget:self action:@selector(yearBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_yearBtn];
        
        // 时间按钮
        _dayBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        _dayBtn.frame = CGRectMake(rect.size.width - kMainW * 0.38, 50, 60, 40);
        _dayBtn.backgroundColor = [UIColor clearColor];
        [_dayBtn setTitle:@"时间" forState:UIControlStateNormal];
        [_dayBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _dayBtn.layer.cornerRadius = 5.0;
        [_dayBtn addTarget:self action:@selector(dayBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_dayBtn];
        
        // 目前时间
        UILabel *timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 7, rect.size.width - completeBtn.frame.size.width - cancelBtn.frame.size.width - 20, 40)];
        timeLabel.font = [UIFont systemFontOfSize:17];
        timeLabel.textColor = [UIColor blackColor];
        timeLabel.textAlignment = NSTextAlignmentCenter;
        NSDate *thisDate = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
        NSString *timeStr = [dateFormatter stringFromDate:thisDate];
        timeLabel.text = timeStr;
        [self addSubview:timeLabel];
    }
    
    return self;
}

- (NSDate *)getDate{

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSDateFormatter *dayFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    [dayFormatter setDateFormat:@"HH:mm:ss"];
    
    NSString *date = [dateFormatter stringFromDate:[self.datePicker date]];
    NSString *time;
    if ([self.datePicker date] == nil) {
        time = [dayFormatter stringFromDate:[NSDate date]];
    }else{
        time = [dayFormatter stringFromDate:[self.dayPicker date]];
    }
    NSString *str = [date stringByAppendingString:time];
    
    NSDateFormatter *combineFormatter = [[NSDateFormatter alloc] init];
    [combineFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [combineFormatter setTimeZone:[NSTimeZone localTimeZone]];
    
    NSDate *totalDate = [combineFormatter dateFromString:str];
    
    return totalDate;
}

#pragma mark - 按钮响应方法
- (void)completeBtnOnClick:(UIButton *)button{

    [self dismiss];
    if (_delegate && [_delegate respondsToSelector:@selector(datePickerView:didClickCompleteBtnWithSelectDate:)]) {
        [_delegate datePickerView:self didClickCompleteBtnWithSelectDate:[self getDate]];
    }
}

- (void)cancelBtnOnClick:(UIButton *)button{
    
    [self dismiss];
}

- (void)dayBtnOnClick:(UIButton *)button{
    
    [self datePickerHid:YES dayPickerHid:NO dayBtnColor:[UIColor orangeColor] yearBtnColor:[UIColor blackColor]];
}

- (void)yearBtnOnClick:(UIButton *)button{

    [self datePickerHid:NO dayPickerHid:YES dayBtnColor:[UIColor blackColor] yearBtnColor:[UIColor orangeColor]];
}

- (void)datePickerHid:(BOOL)datePickerHid dayPickerHid:(BOOL)dayPickerHid dayBtnColor:(UIColor *)dayBtnColor yearBtnColor:(UIColor *)yearBtnColor{
    
    _datePicker.hidden = datePickerHid;
    _dayPicker.hidden = dayPickerHid;
    [_dayBtn setTitleColor:dayBtnColor forState:UIControlStateNormal];
    [_yearBtn setTitleColor:yearBtnColor forState:UIControlStateNormal];
}

- (void)show{

    [UIView animateWithDuration:0.3 animations:^{
        self.frame = CGRectMake(0, 480, 320, 260);
    }];
}

- (void)dismiss{

    [UIView animateWithDuration:0.3 animations:^{
        self.frame = CGRectMake(0, kMainH, kMainW * 0.9, kMainW * 0.5);
    }];
}

@end
