//
//  YFHintViewUtils.h
//  YFUtils
//
//  Created by WangYunFei on 16/11/14.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface YFHintViewUtils : NSObject

/**************************************************************************************
 * 方法名称： // fullWaitingViewForRequest
 * 功能描述： // 添加全屏的等待动画
 * 输入参数： // waitingViewRect:等待动画的rect  waitingText:等待动画的提示文本
 * 输出参数： // UIView
 * 返 回 值： // 等待动画
 * 其它说明： // 其它说明
 **************************************************************************************/
+ (UIView *)fullWaitingViewWith:(CGRect)waitingViewRect text:(NSString *)waitingText;

/**************************************************************************************
 * 方法名称： // hintViewWithImageAndText
 * 功能描述： // 带图片和文本的提示视图
 * 输入参数： // hintViewRect:提示视图的rect hintImage：显示的图片  hintText:显示的文本
 * 输出参数： // UIView
 * 返 回 值： // 提示视图
 * 其它说明： // 其它说明
 **************************************************************************************/
+ (UIView *)hintViewWithImageAndText:(CGRect)hintViewRect hintImage:(UIImage *)hintImage text:(NSString *)hintText ;

/**************************************************************************************
 * 方法名称： // hintViewWithText
 * 功能描述： // 带文本的提示视图
 * 输入参数： // hintViewRect:提示视图的rect hintText:显示的文本 hintTextFont:显示的文本字体
 * 输出参数： // UIView
 * 返 回 值： // 提示视图
 * 其它说明： // 其它说明
 **************************************************************************************/
+ (UIView *)hintViewWithText:(CGRect)hintViewRect hintText:(NSString *)hintText;

/**************************************************************************************
 * 方法名称： // hintViewWithImage
 * 功能描述： // 带图片的提示视图
 * 输入参数： // hintViewRect:提示视图的rect hintImage:显示的图片
 * 输出参数： // UIView
 * 返 回 值： // 提示视图
 * 其它说明： // 其它说明
 **************************************************************************************/
+ (UIView *)hintViewWithImage:(CGRect)hintViewRect hintImage:(UIImage *)hintImage;

@end
