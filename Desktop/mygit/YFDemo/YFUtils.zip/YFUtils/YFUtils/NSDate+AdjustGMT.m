//
//  NSDate+AdjustGMT.m
//  YFUtils
//
//  Created by WangYunFei on 16/11/15.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "NSDate+AdjustGMT.h"

@implementation NSDate (AdjustGMT)

// 获取北京时间
- (NSDate *)GMTDate{

    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate:self];
    NSDate *localeDate = [self dateByAddingTimeInterval:interval];
    
    return localeDate;
}


@end
