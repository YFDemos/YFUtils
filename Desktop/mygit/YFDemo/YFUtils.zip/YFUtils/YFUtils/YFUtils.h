//
//  YFUtils.h
//  YFUtils
//
//  Created by WangYunFei on 16/11/17.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFUtils : NSObject<NSURLConnectionDataDelegate>

/*
 *  获取手机中App当前的版本号
 *
 *  @return NSString
 */
+ (NSString *)getDeviceCurVerison;

/*
 *  获取商店中App最新的版本号
 *
 *  @param appId
 *
 *  @return NSString
 */
+ (NSString *)getAppStoreVerison:(NSString *)appId;

/*
 *  比较版本号
 *
 *  @param oldVersion 旧版本号
 *  @param newVersion 新版本号
 *
 *  @return BOOL
 */
+ (BOOL)compareVersionFromVersion:(NSString *)oldVersion newVersion:(NSString *)newVerison;

/*
 *  判断是否为正确的手机号
 *
 *  @param phoneNum 手机号
 *
 *  @return BOOL
 */
+ (BOOL)isPhoneNumber:(NSString *)phoneNum;

/*
 *  判断是否为正确的邮箱
 *
 *  @param email 邮箱号
 *
 *  @return BOOL
 */
+ (BOOL)isValidateEmail:(NSString *)email;

@end
