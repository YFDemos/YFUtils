//
//  ViewController.m
//  YFUtils
//
//  Created by WangYunFei on 16/11/10.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "ViewController.h"
#import "YFUtils.h"
#import "YFTimeUtils.h"
#import "YFHintViewUtils.h"
#import "NSDate+AdjustGMT.h"
#import "YFDatePicker.h"
#import "YFDatePickerView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    CGRect rect = self.view.frame;
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(150, 200, 100, 30);
    [btn setTitle:@"选择器" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

- (void)click{

    YFDatePickerView *datePicker = [[YFDatePickerView alloc] init];
    datePicker.selectType = YFDatePickerViewType_dateAndTime;
    datePicker.date = [NSDate date];
    [datePicker setFinishHandleBlock:^(id obj, UIButton *sender, id userInfo, BOOL *canDisappear) {
        nil;
    }];
    
    [datePicker show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
