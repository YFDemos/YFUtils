//
//  NSDate+AdjustGMT.h
//  YFUtils
//
//  Created by WangYunFei on 16/11/15.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (AdjustGMT)

- (NSDate *)GMTDate;

@end
