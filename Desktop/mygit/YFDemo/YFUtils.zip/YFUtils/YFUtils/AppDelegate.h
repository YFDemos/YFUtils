//
//  AppDelegate.h
//  YFUtils
//
//  Created by WangYunFei on 16/11/10.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

