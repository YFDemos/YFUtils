//
//  YFUtils.m
//  YFUtils
//
//  Created by WangYunFei on 16/11/17.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import "YFUtils.h"

@implementation YFUtils

// 本机版本
+ (NSString *)getDeviceCurVerison{

    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *appCurVersion = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    return appCurVersion;
}

// 商店版本(系统的block方法，除了全局变量将无法输出参数  自定义的block可以加返回参数输出)
+ (NSString *)getAppStoreVerison:(NSString *)appId{
    
    NSString *urlString = [NSString stringWithFormat:@"http://itunes.apple.com/lookup?id=%@",appId];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionTask *task = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSArray *array = responseDict[@"results"];
        NSDictionary *dict = [array lastObject];
        NSString *versionStr = [dict objectForKey:@"version"];
        
        NSLog(@"%@",versionStr);
    }];
    
    [task resume];

    return 0;
}

// 比较版本号
+ (BOOL)compareVersionFromVersion:(NSString *)oldVersion newVersion:(NSString *)newVerison{
    
    NSArray *oldVer = [oldVersion componentsSeparatedByString:@"."];
    NSArray *newVer = [newVerison componentsSeparatedByString:@"."];
    
    for (NSInteger i = 0; i < MAX(oldVer.count, newVer.count); i++) {
        NSInteger old;
        if (i < oldVer.count) {
            old = [(NSString *)[oldVer objectAtIndex:i] integerValue];
        }else{
            old = 0;
        }
        NSInteger new;
        if (i < newVer.count) {
            new = [(NSString *)[newVer objectAtIndex:i] integerValue];
        }else{
            new = 0;
        }
        if (old < new) {
            return YES;
        }
    }
    
    return NO;
}

// 判断手机号是否正确
+ (BOOL)isPhoneNumber:(NSString *)phoneNum{
    
    /*
     * 手机号码
     * 移动：134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188,1705
     * 联通：130,131,132,152,155,156,185,186,1709
     * 电信：133,1349,153,180,189,1700
     */
    
    //总况
    NSString * phoneNumb = @"^1((3//d|5[0-35-9]|8[025-9])//d|70[059])\\d{7}$";
    
    /*
     * 中国移动：China Mobile
     * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188，1705
     */
    NSString * CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[278])\\d|705)\\d{7}$";
    
    /*
     * 中国联通：China Unicom
     * 130,131,132,152,155,156,185,186,1709
     */
    NSString * CU = @"^1((3[0-2]|5[256]|8[56])\\d|709)\\d{7}$";
    
    /*
     * 中国电信：China Telecom
     * 133,1349,153,180,189,1700
     */
    NSString * CT = @"^1((33|53|8[09])\\d|349|700)\\d{7}$";
    
    /*
     * 大陆地区固话及小灵通
     * 区号：010,020,021,022,023,024,025,027,028,029
     * 号码：七位或八位
     */
    NSString * PHS = @"^0(10|2[0-5789]|\\d{3})\\d{7,8}$";
    
    /**
     *  新增的，比如145,147
     */
    NSString * NEW_ADD = @"^14(5|7)\\d{8}$";
    
    // 规则满足
    NSPredicate *regexTestMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneNumb];
    NSPredicate *regexTestCM = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regexTestCU = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regexTestCT = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    NSPredicate *regexTestPHS = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", PHS];
    NSPredicate *regexTestNEWADD = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",NEW_ADD];
    
    if (([regexTestMobile evaluateWithObject:phoneNum] == YES)
        || ([regexTestCM evaluateWithObject:phoneNum] == YES)
        || ([regexTestCU evaluateWithObject:phoneNum] == YES)
        || ([regexTestCT evaluateWithObject:phoneNum] == YES)
        || ([regexTestPHS evaluateWithObject:phoneNum] == YES)
        || ([regexTestNEWADD evaluateWithObject:phoneNum] == YES)) {
        return YES;
    }else{
        return NO;
    }
}

// 判断邮箱是否正确
+ (BOOL)isValidateEmail:(NSString *)email{
    
    NSString *emailRegex = @"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSPredicate *regexTestEmail = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [regexTestEmail evaluateWithObject:email];
}

@end
