//
//  YFTimeUtils.h
//  YFUtils
//
//  Created by WangYunFei on 16/11/10.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFTimeUtils : NSObject

// 获取当前的年月日星期（X年X月X日，星期X）
+ (NSString *)currentTimeAndWeek;

// 传入date类型和相应格式，得到时间的字符串
+ (NSString *)yearAndMonthTime:(NSDate *)date format:(NSString *)format;

// 传入date类型，得到天数day
+ (NSInteger)dayOfDate:(NSDate *)date;

// 传入date类型，得到月份month
+ (NSInteger)monthOfDate:(NSDate *)date;

// 传入date类型，得到年份year
+ (NSInteger)yearOfDate:(NSDate *)date;

// 传入date类型，得到星期几
+ (NSInteger)weekOfDate:(NSDate *)date;

// 传入date类型，计算月份的天数
- (NSInteger)howManyDaysInThisDate:(NSDate *)date;

/* 传入秒数，输出完整时间
 * return(yyyy年MM月dd日HH:mm)
 */
+ (NSString *)getChineseDetailDate:(long long)seconds;

/* 传入秒数，输出完整时间
 * return(MM月dd日HH:mm)
 */
+ (NSString *)getDateWithoutYear:(long long)seconds;

/* 传入秒数，输出完整时间
 * return(yyyy年MM月dd日)
 */
+ (NSString *)getDateWithoutHourAndMinute:(long long)seconds;

// 得到现在时间的秒数
+ (long long)currentSeconds;

// 得到现在是当月的第几周
+ (NSInteger)weekOfMonth;

// long long to NSDate
+ (NSDate *)dateFromMillis:(long long)millis;

// 是否为同年同月同日
+ (BOOL)isSameDay:(NSDate *)date anotherDate:(NSDate *)anotherDate;

// 是否为同年同月
+ (BOOL)isSameMonth:(NSDate *)date anotherDate:(NSDate *)anotherDate;

// 是否为同年
+ (BOOL)isSameYear:(NSDate *)date anotherDate:(NSDate *)anotherDate;

@end
