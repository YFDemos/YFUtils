//
//  YFDatePicker.h
//  YFUtils
//
//  Created by WangYunFei on 16/12/12.
//  Copyright © 2016年 WangYunFei. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFDatePicker;

@protocol YFDatePickDelegate <NSObject>

/**
 *  确定按钮点击事件
 *
 *  date：选中的日期
 */
- (void)datePickerView:(YFDatePicker *)datePickerView didClickCompleteBtnWithSelectDate:(NSDate *)date;

@end

@interface YFDatePicker : UIView

@property (nonatomic, weak) id <YFDatePickDelegate> delegate;

// 显示datePicker
- (void)show;
// 销毁datePicker;
- (void)dismiss;

@end
